<html>
	<head>
		<meta charset="UTF-8" />
		<title>Menu Principal</title>
		<link rel="stylesheet" href="form.css" />
	</head>
	<body>
	<div id=interface>
	<fieldset>
	<legend>.:: MENU PRINCIPAL ::.</legend>
		<table>
			<tr><td><a href="cadastroartista.php">Cadastro de Artistas</a></td></tr>
			<tr><td><a href="lista_funk.php">Lista de Artistas</a></td></tr>
		</table>
	</fieldset>
	</div>
	</body>
<html>