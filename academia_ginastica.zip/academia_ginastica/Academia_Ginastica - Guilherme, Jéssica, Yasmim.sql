drop database academia_ginastica;

create database Academia_Ginastica;
 
use Academia_Ginastica;
 
create table Tb_Instrutor
(
 Id_instrutor int auto_increment primary key, 
 Nome varchar(50) not null, 
 RG int(9) not null, 
 Dt_nasc date, 
 CPF_inst varchar(11) not null, 
 Titulacao varchar(100) not null, 
 Email varchar(120) not null,
 Endereco varchar(120) not null, 
 Tel_resid int(10), 
 Celular int(11) not null, 
 CEP int(7) not null, 
 Bairro varchar(255) not null, 
 Cidade varchar(100) not null
);

create table Tb_Filiais
(
 Cod_filial int auto_increment primary key,
 Endereco varchar(120) not null,
 Bairro varchar(255) not null, 
 Cidade varchar(100) not null,
 UF char(2)
 );

create table Tb_Turma
(
 Id_turma int auto_increment primary key,
 Cod_filial int,
 Id_instrutor int,
 Num_alunos int(3) not null,
 Horario_aula time not null,
 Tipo_ativd varchar(100) not null,
 Duracao_aula varchar(150),
 Dt_inicio date,
 foreign key (Cod_filial) references Tb_Filiais(Cod_filial),
 foreign key (Id_instrutor) references Tb_Instrutor(Id_instrutor)
); 



create table Tb_Aluno
(
Id_Matricula int auto_increment primary key, 
Id_turma int,
Nome varchar(50) not null, 
RG int(9) not null, 
Dt_nasc date not null, 
CPF varchar(11) not null, 
Dt_Matricula date not null, 
Plano varchar(120) not null,
Altura int(3) not null,
Peso int(4) not null,
Endereco varchar(120) not null, 
Email varchar(120) not null, 
Celular int(11) not null, 
CEP int(7) not null, 
Bairro varchar(255) not null, 
Cidade varchar(100) not null,
UF_aluno char(2),
foreign key (Id_turma) references Tb_turma(Id_turma)
);

create table Tb_Matricula
(
Id_Matricula int,
Id_turma int,
foreign key (Id_turma) references Tb_Turma(Id_turma),
foreign key (Id_Matricula) references Tb_Aluno(Id_Matricula)
);

create table Chamada
(
Id_chamada int auto_increment primary key,
Data_dia date,
presenca char(2),
Id_Matricula int,
foreign key (Id_Matricula) references Tb_Aluno(Id_Matricula)
);